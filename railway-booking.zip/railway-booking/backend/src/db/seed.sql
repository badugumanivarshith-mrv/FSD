INSERT INTO stations (code, name) VALUES
  ('NDLS', 'New Delhi'),
  ('BCT',  'Mumbai Central'),
  ('MAS',  'Chennai Central'),
  ('HWH',  'Howrah Junction'),
  ('SBC',  'Bengaluru City'),
  ('SC',   'Secunderabad'),
  ('PUNE', 'Pune Junction');

INSERT INTO trains (number, name, source_id, dest_id, departs, arrives, fare_per_seat, total_seats) VALUES
  ('12951', 'Mumbai Rajdhani',      (SELECT id FROM stations WHERE code='BCT'),  (SELECT id FROM stations WHERE code='NDLS'), '17:00', '08:30', 1750, 60),
  ('12952', 'Delhi Rajdhani',       (SELECT id FROM stations WHERE code='NDLS'), (SELECT id FROM stations WHERE code='BCT'),  '16:55', '08:35', 1750, 60),
  ('12621', 'Tamil Nadu Express',   (SELECT id FROM stations WHERE code='NDLS'), (SELECT id FROM stations WHERE code='MAS'),  '22:30', '07:10', 1650, 72),
  ('12622', 'Tamil Nadu Express',   (SELECT id FROM stations WHERE code='MAS'),  (SELECT id FROM stations WHERE code='NDLS'), '22:00', '06:40', 1650, 72),
  ('12839', 'Howrah Chennai Mail',  (SELECT id FROM stations WHERE code='HWH'),  (SELECT id FROM stations WHERE code='MAS'),  '23:45', '05:30', 980,  80),
  ('12723', 'Telangana Express',    (SELECT id FROM stations WHERE code='SC'),   (SELECT id FROM stations WHERE code='NDLS'), '06:25', '05:15', 1450, 72),
  ('12724', 'Telangana Express',    (SELECT id FROM stations WHERE code='NDLS'), (SELECT id FROM stations WHERE code='SC'),   '07:40', '06:30', 1450, 72),
  ('12785', 'Secunderabad Bengaluru Express', (SELECT id FROM stations WHERE code='SC'),  (SELECT id FROM stations WHERE code='SBC'), '19:00', '05:50', 720, 90),
  ('12786', 'Bengaluru Secunderabad Express', (SELECT id FROM stations WHERE code='SBC'), (SELECT id FROM stations WHERE code='SC'),  '18:30', '05:20', 720, 90),
  ('11029', 'Koyna Express',        (SELECT id FROM stations WHERE code='BCT'),  (SELECT id FROM stations WHERE code='PUNE'), '08:10', '12:40', 310,  100);
